package com.example.homework6_instagramclone.ui.fragment


import androidx.fragment.app.Fragment
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.navArgs
import com.example.homework6_instagramclone.databinding.FragmentPostBinding
import com.example.homework6_instagramclone.databinding.FragmentPostBinding.inflate


class PostFragment : Fragment() {
    private lateinit var binding: FragmentPostBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentPostBinding.inflate(inflater, container, false)

        val bundle : PostFragmentArgs by navArgs()
        val post = bundle.postNesnesi

        binding.imageViewPost.setImageResource(
            resources.getIdentifier(post.resim, "drawable", requireContext().packageName)
        )
        binding.textViewKullaniciAdi.text = post.kullaniciAdi

        binding.imageViewProfilFoto.setImageResource(
            resources.getIdentifier(post.profil,"drawable",requireContext().packageName)
        )
        return binding.root

    }
}