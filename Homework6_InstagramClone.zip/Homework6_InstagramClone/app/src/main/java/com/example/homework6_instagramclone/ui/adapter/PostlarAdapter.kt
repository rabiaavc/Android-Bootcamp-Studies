package com.example.homework6_instagramclone.ui.adapter

import android.content.Context
import android.view.ViewGroup
import android.view.LayoutInflater
import androidx.recyclerview.widget.RecyclerView
import com.example.homework6_instagramclone.data.entity.Postlar
import com.example.homework6_instagramclone.databinding.CardTasarimBinding
import android.util.Log
import androidx.navigation.Navigation
import com.example.homework6_instagramclone.R  // R dosyasını düzgün import et
import com.example.homework6_instagramclone.ui.fragment.AnasayfaFragmentDirections

class PostlarAdapter(var mContext: Context, var postlarListesi: List<Postlar>) :
    RecyclerView.Adapter<PostlarAdapter.CardTasarimHolder>() {

    inner class CardTasarimHolder(var tasarim: CardTasarimBinding) : RecyclerView.ViewHolder(tasarim.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardTasarimHolder {
        val binding = CardTasarimBinding.inflate(LayoutInflater.from(mContext), parent, false)
        return CardTasarimHolder(binding)
    }

    override fun onBindViewHolder(holder: CardTasarimHolder, position: Int) {
        val post = postlarListesi[position]
        val t = holder.tasarim

        val resId = mContext.resources.getIdentifier(post.resim, "drawable", mContext.packageName)
        Log.e("PostlarAdapter", "post.resim: ${post.resim}, resId: $resId")

        if (resId != 0) {
            t.imageVPost.setImageResource(resId)
        } else {
            Log.e("PostlarAdapter", "Resim bulunamadı: ${post.resim}")
            // Burada test amaçlı Android sistem görseli kullanabilirsin
            t.imageVPost.setImageResource(android.R.drawable.ic_menu_report_image)
        }


        t.cardViewPost.setOnClickListener {
                val gecis = AnasayfaFragmentDirections.postGecis(postNesnesi = post)
                Navigation.findNavController(it).navigate(gecis)
        }
    }

    override fun getItemCount(): Int {
        return postlarListesi.size
    }
}
