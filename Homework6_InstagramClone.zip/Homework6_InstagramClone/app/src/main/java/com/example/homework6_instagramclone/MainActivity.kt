package com.example.homework6_instagramclone

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() { //MainActivity bizim ekranımız.
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState) //onCreate metodu: Ekran ilk açıldığında ne yapılacağını tanımlarsın.
        setContentView(R.layout.activity_main)//setContentView(...): Hangi XML dosyasının (arayüzün) bu Activity'e bağlı olduğunu belirtirsin.
    }
}