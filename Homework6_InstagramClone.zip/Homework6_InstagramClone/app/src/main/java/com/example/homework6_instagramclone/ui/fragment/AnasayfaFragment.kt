package com.example.homework6_instagramclone.ui.fragment

import android.health.connect.datatypes.SleepSessionRecord
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.example.homework6_instagramclone.R
import com.example.homework6_instagramclone.data.entity.Postlar
import com.example.homework6_instagramclone.databinding.FragmentAnasayfaBinding
import com.example.homework6_instagramclone.ui.adapter.PostlarAdapter

class AnasayfaFragment : Fragment() {
    private lateinit var binding: FragmentAnasayfaBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentAnasayfaBinding.inflate(inflater, container, false)
        binding.toolbarAnasayfa.title = "Keşfet"
        binding.anasayfaRv.layoutManager =
            StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL)



        val PostlarListesi = ArrayList<Postlar>()
        val manzara1 = Postlar(1, "manzara1","brandon123","kisi1")
        val manzara2 = Postlar(2, "manzara2","lisa10","kisi2")
        val manzara3 = Postlar(3, "manzara3","ahmet01","kisi3")
        val manzara4 = Postlar(4, "manzara4","melisa_melisa","kisi4")
        val manzara5 = Postlar(5, "manzara5","merttt","kisi5")
        val manzara6 = Postlar(6, "manzara6","elif45","kisi6")
        val manzara7 = Postlar(7, "manzara7","lisa","kisi7")
        val manzara8 = Postlar(8, "manzara8","jack","kisi8")
        val manzara9 = Postlar(9, "manzara9","rabiaa","kisi9")
        val manzara10 = Postlar(10, "manzara10","rabiaa","kisi9")
        val manzara11 = Postlar(11, "manzara11","rabiaa","kisi9")
        val manzara14 = Postlar(14, "manzara14","ahmet01","kisi3")
        val manzara15 = Postlar(15, "manzara15","brandon123","kisi1")
        val manzara16 = Postlar(16, "manzara16","ahmet01","kisi3")

        val yapi1 = Postlar(17,"yapi1","lisa","kisi7")
        val yapi2 = Postlar(18,"yapi2","jack","kisi8")
        val yapi3 = Postlar(19,"yapi3","elif45","kisi6")
        val yapi4 = Postlar(20,"yapi4","brandon123","kisi1")
        val yapi5 = Postlar(21,"yapi5","melisa_melisa","kisi4")
        val yapi6 = Postlar(22,"yapi6","rabiaa","kisi9")
        val yapi7 = Postlar(23,"yapi7","elif45","kisi6")
        val yapi8 = Postlar(24,"yapi8","merttt","kisi5")
        val yapi9 = Postlar(15,"yapi9","melisa_melisa","kisi4")
        val yapi10 = Postlar(26,"yapi10","brandon123","kisi1")
        val yapi11 = Postlar(27,"yapi11","merttt","kisi5")
        val yapi12 = Postlar(28,"yapi12","lisa","kisi7")
        val yapi13 = Postlar(29,"yapi13","melisa_melisa","kisi4")
        val yapi14 = Postlar(30,"yapi14","elif45","kisi6")
        val yapi15 = Postlar(31,"yapi15","melisa_melisa","kisi4")
        val yapi16 = Postlar(32,"yapi16","jack","kisi8")

        PostlarListesi.add(manzara1)
        PostlarListesi.add(manzara2)
        PostlarListesi.add(manzara3)
        PostlarListesi.add(manzara4)
        PostlarListesi.add(manzara5)
        PostlarListesi.add(manzara6)
        PostlarListesi.add(manzara7)
        PostlarListesi.add(manzara8)
        PostlarListesi.add(manzara9)
        PostlarListesi.add(manzara10)
        PostlarListesi.add(manzara11)
        PostlarListesi.add(manzara14)
        PostlarListesi.add(manzara15)
        PostlarListesi.add(manzara16)

        PostlarListesi.add(yapi1)
        PostlarListesi.add(yapi2)
        PostlarListesi.add(yapi3)
        PostlarListesi.add(yapi4)
        PostlarListesi.add(yapi5)
        PostlarListesi.add(yapi6)
        PostlarListesi.add(yapi7)
        PostlarListesi.add(yapi8)
        PostlarListesi.add(yapi9)
        PostlarListesi.add(yapi11)
        PostlarListesi.add(yapi12)
        PostlarListesi.add(yapi13)
        PostlarListesi.add(yapi14)
        PostlarListesi.add(yapi15)
        PostlarListesi.add(yapi16)

        val postlarAdapter = PostlarAdapter(requireContext(), PostlarListesi)

        binding.anasayfaRv.adapter = postlarAdapter

        return binding.root
    }
}
