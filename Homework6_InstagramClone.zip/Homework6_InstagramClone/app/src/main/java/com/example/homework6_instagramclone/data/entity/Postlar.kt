package com.example.homework6_instagramclone.data.entity

import java.io.Serializable


data class Postlar(var id:Int,
                   var resim: String,
                   var kullaniciAdi:String,
                    var profil:String) : Serializable{

}